<?php
if (!defined('ABSPATH')) exit;

class WC_Gateway_NumberPayments extends WC_Payment_Gateway
{

  protected $NumberAPI;
  protected NumberPayments_Config $config;
  protected NumberPayments_Encryption $decryptor;

  // -------------------------
  // Declared properties (PHP 8.2 safe)
  // -------------------------
  public string $account_code = '';
  public string $token = ''; 
  public string $merchant_id = '';
  public string $api_url = '';
  public string $eVisible = '';
  public string $eReadOnly = '';
  public string $eStyles = '';
  public string $eColors = '';
  public bool $useWallets = false;

  protected $sesskey = null;

  // -------------------------
  // Constructor
  // -------------------------
  public function __construct() {  

    $this->id                 = 'numberpayments';
    $this->method_title       = 'NumberPayments';
    $this->method_description = 'Pay using NumberPayments hosted iframe.';
    $this->has_fields         = true;
    $this->supports           = ['products', 'tokenization', 'add_payment_method', 'refunds'];

    $this->init_form_fields();
    $this->init_settings();

    // Load settings
    $this->account_code = (string) $this->get_option('account_code', '');
    $this->token        = (string) $this->get_option('token', '');
    $this->merchant_id = absint($this->get_option('merchant_id', 0));
    $this->api_url      = (string) $this->get_option('api_url', '');
    $this->eVisible     = (string) $this->get_option('eVisible', '');
    $this->eReadOnly    = (string) $this->get_option('eReadOnly', '');
    $this->eStyles      = (string) $this->get_option('eStyles', '');
    $this->eColors      = (string) $this->get_option('eColors', '');
    $this->useWallets   = (bool) $this->get_option('useWallets', false);

    $this->config = new NumberPayments_Config(
      $this->account_code,
      $this->token,
		  $this->get_option('apikey', ''),
      $this->merchant_id,
      $this->api_url,
      $this->get_option('eIndex', ''),
      $this->get_option('capture_mode', 'payment'),
      $this->eVisible,
      $this->eReadOnly,
      $this->eStyles,
      $this->eColors,
			$this->get_option('savedcard_eVisible', ''),
      $this->get_option('savedcard_eReadOnly', ''),
      $this->get_option('savedcard_eStyles', ''),
      $this->get_option('savedcard_eColors', ''),
      $this->get_option('useWallets', 'no') === 'yes',
      $this->get_option('apple_domain', ''), 'no',
      $this->get_option('AVSPartialMatch', 'no') === 'yes',
      $this->get_option('CVVMatch', 'no') === 'yes'
    );

    // additional classes
    $this->NumberAPI = new numberpayments_api($this->config);


    // Admin save
    // Only load admin hooks in admin.
    if (is_admin()) {
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    // Receipt page
    add_action('woocommerce_receipt_' . $this->id, [$this, 'receipt_page']);

    add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    add_action('admin_enqueue_scripts', [$this, 'numberpayments_admin_styles']);
    add_action('woocommerce_order_status_cancelled', [$this, 'stop_payment'], 10, 1);

    // stored card methods
    remove_action('woocommerce_account_add-payment-method_endpoint', 'woocommerce_account_add_payment_method');
    add_action('woocommerce_account_add-payment-method_endpoint', [$this, 'render_add_payment_method_iframe']);	
		
    add_action('wp_ajax_numberpayments_js_error', [$this, 'numberpayments_js_error']);
    add_action('wp_ajax_nopriv_numberpayments_js_error', [$this, 'numberpayments_js_error']);

    //add_action('wp_ajax_numberpayments_create_session', [$this,'create_payment_session']);
    //add_action( 'wp_ajax_nopriv_numberpayments_create_session', [$this,'create_payment_session']);

    // order callback from Number
    add_action('rest_api_init',  [$this, 'register_rest_routes'] );
  }


  // -------------------------
  // Admin fields
  // -------------------------
  public function init_form_fields(): void
  {
    $this->form_fields = [
      'enabled' => [
        'title' => 'Enable/Disable',
        'type' => 'checkbox',
        'label' => 'Enable NumberPayments',
        'default' => 'no',
      ],
      'title' => [
        'title' => 'Title',
        'type' => 'text',
        'default' => 'Credit Card Payment',
      ],
      'description' => [
        'title' => 'Description',
        'type' => 'textarea',
        'default' => 'Pay securely using NumberPayments.',
      ],

      'api_credentials_section' => [
        'title' => '
        <div class="my-gateway-settings-card">
            <div class="my-gateway-settings-title">API Credentials</div>

            <div class="my-gateway-settings-description">
                Enter the credentials provided by your payment gateway.
            </div>
        </div>
    ',
        'type' => 'title',
      ],


      'account_code' => ['title' => 'Account Code', 'type' => 'text'],
      'token'        => ['title' => 'Token', 'type' => 'password'],
			'apikey'        => ['title' => 'API Key', 'type' => 'password'],
      'merchant_id'  => ['title' => 'Merchant ID', 'type' => 'text'],
      'api_url'      => ['title' => 'API URL', 'type' => 'text'],
      'eIndex'       => ['title' => 'eIndex', 'type' => 'text', 'description' => 'key index for encryption'],

      // --- SECTION 2 (This acts as the visual divider) ---
      'checkout_display_section' => [
        'title' => '
        <div class="my-gateway-settings-card">
            <div class="my-gateway-settings-title">Payment Form Fields and Styling</div>

            <div class="my-gateway-settings-description">
                Use the <a href="https://easypay8.com/byopayform/" target="_blank"> PayForm Builder tool</a> to help configure these settings
            </div>
        </div>
    ',
        'type' => 'title',
      ],

      'capture_mode' => array(
        'title'       => 'Widget Type',
        'type'        => 'select',
        'description' => 'Choose which transaction type you would like to collect.',
        'default'     => 'payment',
        'options'     => array(
          'payment'    => 'Payment',
          'combination' => 'Combo',
        ),
      ),
      'eVisible' => array(
        'title'   => 'Visible',
        'type'    => 'text',
        'description' => 'Determine which fields you want visible on your form.',
        'default' => '0600',
      ),
      'eReadOnly' => array(
        'title'   => 'ReadOnly',
        'type'    => 'text',
        'description' => 'Should any of the chosen fields be read only?',
        'default' => '0000',
      ),
      'eStyles' => array(
        'title'   => 'Styles',
        'type'    => 'text',
        'default' => '0001',
      ),
      'eColors' => array(
        'title'   => 'Colors',
        'type'    => 'text',
        'default' => '#ffffff,#428bca,#007bff,#212121,#ffffff,#212121,#ffffff',
      ),

			 // --- SECTION 3  ---
      'savedcard_display_section' => [
        'title' => '
        <div class="my-gateway-settings-card">
            <div class="my-gateway-settings-title">Saved Card Fields and Styling</div>

            <div class="my-gateway-settings-description">
                Use the <a href="https://easypay8.com/byopayform/" target="_blank"> PayForm Builder tool</a> to help configure these settings
            </div>
        </div>
    ',
        'type' => 'title',
      ],

      'savedcard_eVisible' => array(
        'title'   => 'Visible',
        'type'    => 'text',
        'description' => 'Determine which fields you want visible on the save card form.',
        'default' => '0600',
      ),
      'savedcard_eReadOnly' => array(
        'title'   => 'ReadOnly',
        'type'    => 'text',
        'description' => 'Should any of the chosen fields be read only?',
        'default' => '0000',
      ),
      'savedcard_eStyles' => array(
        'title'   => 'Styles',
        'type'    => 'text',
        'default' => '0001',
      ),
      'savedcard_eColors' => array(
        'title'   => 'Colors',
        'type'    => 'text',
        'default' => '#ffffff,#428bca,#007bff,#212121,#ffffff,#212121,#ffffff',
      ),

      // 'display_section_end' => [ 'type'  => 'sectionend',    ],
      'features_display_section' => [
        'title' => '
        <div class="my-gateway-settings-card">
            <div class="my-gateway-settings-title">Configuration and Features</div>            
        </div>
    ',
        'type' => 'title',
      ],
      'useWallets' => array(
        'title'   => 'Enable Wallets',
        'type'    => 'checkbox',
        'label'       => 'Allow Apple Pay / Google Pay',
        'description' => 'Displays supported digital wallets during checkout.',
        'default'     => 'no',
      ),
      'apple_domain'   => ['title' => 'Apple Pay Domain', 'type' => 'text', 'description' => 'The domain that has been registered with Apple.'],

      'AVSPartialMatch' => array(
        'title'   => 'AVS Partial Match',
        'type'    => 'checkbox',
        'label'       => 'Require AVS Partial Match',
        'description' => 'The zip code entered must match what is on file with the card issuer.',
        'default'     => 'no',
      ),
      'CVVMatch' => array(
        'title'   => 'CVV Match',
        'type'    => 'checkbox',
        'label'       => 'Require CVV Match',
        'description' => 'The transaction will be voided if the CVV does not match what is on file with the card issuer.',
        'default'     => 'no',
      ),

    ];
  }

  public function process_admin_options()
  {

    $saved = parent::process_admin_options();

    // Clear cached API session/token after settings change.
    delete_transient('my_api_gateway_sesskey');

    return $saved;
  }

  public function numberpayments_admin_styles($hook)
  {

    // Only load on WooCommerce settings page
    if ('woocommerce_page_wc-settings' !== $hook) {
      return;
    }

    wp_enqueue_style(
      'numberpayments-admin-styles',
      plugin_dir_url(__FILE__) . 'numberpayments1.1.css',
      [],
      '1.0'
    );
  }


  public function enqueue_assets()
  {

    // Only load where needed
    if (! is_checkout() && ! is_add_payment_method_page() && ! is_order_received_page()) {
      return;
    }

    // Styles (only where needed)
    if (is_checkout() || is_order_received_page() || is_add_payment_method_page()) {
      wp_enqueue_style(
        'numberpayments-styles',
        plugin_dir_url(__FILE__) . 'numberpayments1.1.css',
        [],
        '1.0'
      );
    }

    // Scripts (checkout + add payment method)
    if (is_checkout() || is_add_payment_method_page()) {

      wp_enqueue_script(
        'my-gateway-tokenization',
        plugin_dir_url(__FILE__) . 'numberpayments.js',
        ['jquery'],
        '1.0',
        true
      );

      $scriptConfig = [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('my_gateway_nonce'),
        'origin'   => 'https://easypay5.com',
        'restUrl'  => rest_url('number/v1/decrypt'),
      ];
      wp_add_inline_script(
        'my-gateway-tokenization',
        'window.myGateway = window.myGateway || {}; Object.assign(window.myGateway, ' . wp_json_encode($scriptConfig) . ');',
        'before'
      );
    }
  }



	public function register_rest_routes() {

        register_rest_route(
            'numberpayments/v1',
            '/callback',
            [
                'methods'  => 'POST',
                'callback' => [$this, 'handle_callback'],
                'permission_callback' => '__return_true',
            ]
        );

    }

  public function payment_fields()
  {

    // Show description if you set one in the gateway settings
    if ($this->description) {
      echo wpautop(wp_kses_post($this->description));
    }

    if (is_add_payment_method_page()) {
      $this->render_add_payment_method_iframe();
      return;
    }

		echo '<div id="number-gateway-total" data-order-total="' . esc_attr( WC()->cart->total ) . '"></div>';

    echo '<div class="my-gateway-payment-fields">';

    // Logged-in users show saved cards
    if (is_user_logged_in()) {
      $this->saved_payment_methods();
		}


			// removed for one click checkout
			/*
			$tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->id );
			if ( ! empty( $tokens ) ) {
        $new_card_note = apply_filters('my_gateway_new_card_note',  __( 'Choose "Use a new payment method" to enter a new card.', 'my-payment-gateway' ), $this);

        echo '<p class="my-gateway-new-card-note">';
        echo wp_kses_post($new_card_note);
        echo '</p>';
     }     
    } 
		else {
      $guest_message = apply_filters( 'my_gateway_guest_message', 'You can save your payment details after creating an account.', $this );
      echo '<p>' . wp_kses_post($guest_message) . '</p>';
    }
		*/

		// payform Iframe
		static $rendered = false;
    if ($rendered) return;
    $rendered = true;

		 try {
      $iframe_url = $this->NumberAPI->generate_iframe_url(WC()->cart->get_cart_contents_total());
    } 
		catch (Exception $e) {
      $this->log_exception($e, ['user_id' => get_current_user_id(), 'action' => 'Generate Payment URL']);
      wc_add_notice('Unable to generate payment form.', 'error');
      return;
    }

    if (!$iframe_url) {
      wc_add_notice('Unable to generate payment form.', 'error');
      return;
    }

		$iframe_class = is_user_logged_in() ? 'my-gateway-iframe-wrapper my-gateway-new-card-hidden' : 'my-gateway-iframe-wrapper';		
		?>
    <div class="<?php echo esc_attr( $iframe_class ); ?>">
      <iframe allow="payment" class="my-gateway-iframe" src="<?php echo esc_url( $iframe_url ); ?>"></iframe>
    </div>
    <?php


    echo '</div>';
  }


  // -------------------------
  // Process payment (redirect to receipt)
  // -------------------------
  public function process_payment($order_id)
  {
    $order = wc_get_order($order_id);

    // check if user selected a stored Card				
    $token_id = isset($_POST['wc-' . $this->id . '-payment-token']) ? wc_clean($_POST['wc-' . $this->id . '-payment-token']) : null;


    // CASE 1: Saved card selected   
    if ($token_id && $token_id !== 'new') {

      $token = WC_Payment_Tokens::get($token_id);

      // Validate token ownership
      if (!$token || $token->get_user_id() !== get_current_user_id()) {
        wc_add_notice('Invalid saved payment method.', 'error');
        return;
      }

      // prevent duplicate charges
      if ($order->is_paid()) {
        return [
          'result'   => 'success',
          'redirect' => $this->get_return_url($order),
        ];
      }

      //  Charge using your API
      try {
        $transactionID = $this->NumberAPI->charge_consent($token->get_token(), $order->get_total());
      } catch (Exception $e) {
        $this->log_exception($e, ['consent_id' => $token->get_token(), 'user_id' => get_current_user_id(), 'action' => 'Charge stored card']);
        wc_add_notice('Unable to process your card. Please try again.', 'error');
        return;
      }

      if ($transactionID == 0) {
        wc_add_notice('Payment failed. Please try another method.', 'error');
        return;
      }

      if ($transactionID > 0) {
        $order->payment_complete($transactionID);
        $order->add_order_note('Payment completed using saved card ' . $token->get_last4());
        $order->save();

        // Empty cart (Woo doesn't always do this automatically in custom flows)
        WC()->cart->empty_cart();

        return [
          'result'   => 'success',
          'redirect' => $this->get_return_url($order),
        ];
      }
    }


// CASE 2: New card (iframe flow)

$order->update_status( 'pending','Awaiting NumberPayments payment');

$order->save();

WC()->session->set( 'order_awaiting_payment', $order_id);

return [
    'result' => 'success',
    'redirect' => '',
];


  }



  // -------------------------
  // add payment method on account page
  // -------------------------

  public function add_payment_method() {  

    if (empty($_POST['my_gateway_card_token'])) {
      wc_add_notice('No card token received.', 'error');
      error_log('Error adding card, no my_gateway_card_token received. cust= ' . get_current_user_id());
      return;
    }

    $token_value = wc_clean($_POST['my_gateway_card_token']);

    // validate consent using Number API and get card details
    try {
      $stored_card = $this->NumberAPI->validate_consent($token_value);
    } catch (Exception $e) {
      $this->log_exception($e, ['consent_id' => $token_value, 'user_id' => get_current_user_id(), 'action' => 'Validate stored card']);
      wc_add_notice('Unable to validate your card. Please try again.', 'error');
      return [
        'result' => 'failure',
      ];
    }

    if (is_user_logged_in()) {
      $token = new WC_Payment_Token_CC();
      $token->set_token($token_value);
      $token->set_gateway_id($this->id);
      $token->set_card_type($stored_card->getBrand());
      $token->set_last4($stored_card->getLast4());
      $token->set_expiry_month($stored_card->getExpiryMonth());
      $token->set_expiry_year($stored_card->getExpiryYear());
      $token->set_user_id(get_current_user_id());
      $token->save();
    }

    return [
      'result'   => 'success',
      'redirect' => wc_get_account_endpoint_url('payment-methods'),
    ];
  }

  // -------------------------
  // delete payment method from account page
  // -------------------------

  public function delete_saved_payment($token_id, $token) {  

    if (!$token || !method_exists($token, 'get_token')) {
      error_log('Invalid token object passed to delete_saved_payment');
      return;
    }

    // This is the remote reference (e.g., Number's consent id)
    $remote_token = $token->get_token();

    try {
      $this->NumberAPI->delete_consent($remote_token);
    } catch (Exception $e) {
      $this->log_exception($e, ['consent_id' => $cid, 'user_id' => get_current_user_id(), 'action' => 'delete_consent']);
      wc_add_notice('Could not remove card.', 'error');
    }
  }

  //
  // API call to get iframe for save card ONLY
  //
  public function render_add_payment_method_iframe() { 

    static $has_run = false;

    if ($has_run || ! is_main_query()) {
      return;
    }

    $has_run = true;
    $customer = new WC_Customer(get_current_user_id());
    try {
      $iframe_url = $this->NumberAPI->generate_consent_url($customer);
    } catch (Exception $e) {
      $this->log_exception($e, ['consent_id' => '0', 'user_id' => get_current_user_id(), 'action' => 'Create consent Iframe URL']);
      wc_add_notice('Could not generate form for saving a card.', 'error');
      return;
    }

  ?>
    <form id="add_payment_method" method="post">
      <input type="hidden" name="woocommerce_add_payment_method" value="1">
      <?php wp_nonce_field('woocommerce-add-payment-method', 'woocommerce-add-payment-method-nonce'); ?>
      <div class="my-gateway-iframe-wrapper">
        <h3>Add Payment Method</h3>
        <p>Enter your card details below:</p>
        <iframe allow="payment" class="my-gateway-iframe" src="<?php echo esc_url($iframe_url); ?>"></iframe>
        <input type="hidden" id="my_gateway_card_token" name="my_gateway_card_token" />
        <input type="hidden" name="payment_method" value="<?php echo esc_attr($this->id); ?>" />
      </div>
    </form>
<?php

  }

  //------------------------------------------
  // Check txid against number's API query to prevent spoofing
  // (Currently not in use, other security methods deployed)
	// -----------------------------------------
  public function validate_txid(string $txid, WC_Order $order): bool
  {

    if (!$txid || !$order) {
      return false;
    }

    $okToContinue = false;
    try {
      $okToContinue = $this->NumberAPI->validate_transaction($txid, $order);
    } catch (Exception $e) {
      $this->log_exception($e, ['txid' => $txid, 'user_id' => get_current_user_id(), 'action' => 'validate transaction']);
    }

    // if this transaction was spoofed, lets void it
    if (! $okToContinue) {
      try {
        $this->NumberAPI->void_payment($txid);
      } catch (Exception $e) {
        $this->log_exception($e, ['txid' => $txid, 'user_id' => get_current_user_id(), 'action' => 'void_payment']);
      }
    }

    return $okToContinue;
  }

  //-----------------
  // refund a payment
  //-----------------
  public function process_refund($order_id, $amount = null, $reason = '')
  {

    $order = wc_get_order($order_id);
    $transaction_id = $order->get_transaction_id();

    if (!$transaction_id) {
      error_log('Missing transaction ID');
      return false;
    }

    try {
      $this->NumberAPI->apply_credit($transaction_id, $amount);
      wc_get_logger()->info('Payment TXID ' . $transaction_id . ' was refunded ' . $amount);
      $order->add_order_note('Payment TXID ' . $transaction_id . ' was refunded ' . $amount);
      $order->save();
    } catch (Exception $e) {
      $this->log_exception($e, ['tx_id' => $transaction_id, 'user_id' => get_current_user_id(), 'action' => 'Refund Payment']);

      $order->add_order_note('Refund failed: ' . $e->getMessage());
      $order->save();

      // This shows the error to the admin user
      return new WP_Error('refund_error',  __('Refund failed: ' . $e->getMessage(), 'your-textdomain'));
    }

    return true;
  }

  // -------------------------
  // order was cancelled, try to void payment
  // -------------------------
  public function stop_payment($order_id)
  {
    error_log(' in stop_payment' . $order_id);
    $order = wc_get_order($order_id);

    // Only handle our gateway
    if ($order->get_payment_method() !== $this->id) {
      return;
    }

    $txid = $order->get_transaction_id();

    if (!$txid) {
      return;
    }

    // Prevent duplicate voids
    if ($order->get_meta('_payment_voided')) {
      return;
    }

    try {
      $this->NumberAPI->void_payment($txid);
      $order->add_order_note('Payment successfully voided.');
      $order->update_meta_data('_payment_voided', 'yes');
      $order->save();
    } catch (Throwable $e) {
      $order->add_order_note('Void payment failed: ' . $e->getMessage());

      wc_get_logger()->info(
        'Void payment authorization failed for order ' . $order_id . ': ' . $e->getMessage(),
        ['source' => $this->id]
      );
    }
  }

  //--------------------------------------
  // process combo (payment and save card)
  //---------------------------------------
  public static function process_combo() {  

    check_ajax_referer('my_gateway_nonce', 'security');
    $order_id = WC()->session ? WC()->session->get('order_awaiting_payment') : 0;
    $txid  = sanitize_text_field($_POST['txid'] ?? '');
    $cid  = intval($_POST['cid'] ?? 0);
    $cardno = sanitize_text_field($_POST['card'] ?? '');
    $cardtype = sanitize_text_field($_POST['cardtype'] ?? '');
    $fee_amount = (isset($_POST['fee']) && is_numeric($_POST['fee'])) ? (float) $_POST['fee'] : 0;
    $order = wc_get_order($order_id);

    if (!$order || !$txid) {
      error_log('Invalid parameters for process_combo ' . 'orderId' . $order_id);
      wc_get_logger()->error('Invalid parameters for process_combo ' . 'orderId' . $order_id, ['source' => 'number-payments']);
      wp_send_json_error(['message' => 'Invalid data']);
      return;
    }

    $details = trim($cardtype . ' ' . $cardno);
    $note = 'Payment completed via PayForm. TXID: ' . $txid;
    if (! empty($details)) {
      $note .= '. Card: ' . $details;
    }

    // surcharge
    if ($fee_amount > 0) {

      $fee = new WC_Order_Item_Fee();

      $fee->set_name('Credit Card Surcharge');
      $fee->set_amount($fee_amount);
      $fee->set_total($fee_amount);
      $order->add_item($fee);
      $order->calculate_totals();
    }

    $order->add_order_note($note);
    $order->set_transaction_id($txid);
    $order->payment_complete($txid);
    $order->save();


    if (is_user_logged_in() && $cid > 0) {
      // format expiration date returned from widget
      [$month, $year] = explode('/', $_POST['expires']);

      $token = new WC_Payment_Token_CC();
      $token->set_token($cid);
      $token->set_gateway_id('numberpayments');
      $token->set_card_type($cardtype);
      $token->set_last4($cardno);
      $token->set_expiry_month($month);
      $token->set_expiry_year('20' . $year);
      $token->set_user_id(get_current_user_id());
      $token->save();
    }

    wp_send_json_success([
      'redirect' => $order->get_checkout_order_received_url()
    ]);
  }

	//--------------------------------------
  // process void
	// this method should only be hit if woo error after payment completed
  //---------------------------------------
  public static function process_void() {  

    check_ajax_referer('my_gateway_nonce', 'security');
    $order_id = WC()->session ? WC()->session->get('order_awaiting_payment') : 0;    
    $order = wc_get_order($order_id);
		$txid = WC()->session->get( 'transactionToVoid', 0);		

    if (!$order || !$txid) {
      error_log('Invalid parameters for process_void ' . 'orderId' . $order_id);
      wc_get_logger()->error('Invalid parameters for process_void ' . 'orderId' . $order_id, ['source' => 'number-payments']);    
		  $order->add_order_note('Void payment failed.');
      return;
    } 
		
		try {

		  $gateway = new WC_Gateway_NumberPayments();

      $gateway->NumberAPI->void_payment($txid);	
			$order->add_order_note('Payment Voided. Encryption key mismatch');    
      $order->save(); 
		  wc_add_notice( 'An error occurred while completing the order. Your credit card charge has been voided.', 'error' );
		  wp_send_json_success([ 'message' => 'An error occurred while completing the order. Your credit card charge has been voided.']);
    } 
		catch (Exception $e) {
      $gateway->log_exception($e, ['txid' => $txid, 'user_id' => get_current_user_id(), 'action' => 'void_payment']);
			wp_send_json_error([ 'message' => 'An error occurred while completing the order.']);
    }	    
  }


  // -----------------------------------------
  // Log errors to both woocommerce and php log
  //------------------------------------------
  private function log_exception(Exception $e, array $context = []): void
  {

    $base_message = sprintf('[%s] %s', get_class($e), $e->getMessage());

    // Append context in a readable way
    if (!empty($context)) {
      $base_message .= ' | context: ' . wp_json_encode($context);
    }

    error_log($base_message);

    wc_get_logger()->error($base_message, ['source' => 'number-payments']);
  }

	// ------------------
	// log javascript errors
	// ---------------------
	function numberpayments_js_error() {

    check_ajax_referer('my_gateway_nonce',  'nonce');		

    $message = sanitize_text_field(
        $_POST['message'] ?? 'Unknown JS error'
    );

    $data = [];

    if (!empty($_POST['data'])) {
        $data = json_decode(
            wp_unslash($_POST['data']),
            true
        );
    }

    $logger = wc_get_logger();

    $logger->error(
        $message . ' ' . wp_json_encode($data),
        [
            'source' => 'number-payments'
        ]
    );

    wp_send_json_success();
}

  // -------------------------
  // Validate Admin settings
  // -------------------------
  public function validate_api_url_field($key, $value) {  
    return NumberPayments_Validate::validate_api_url($value);
  }

  public function validate_merchant_id_field($key, $value) {
    return NumberPayments_Validate::validate_merchant_id($value);
  }

  public function validate_account_code_field($key, $value) {  
    return NumberPayments_Validate::check_required($value, 'Account Code');
  }

  public function validate_token_field($key, $value) {  
    return NumberPayments_Validate::check_required($value, 'Acount Token');
  }

  public function validate_eindex_field($key, $value) {  
    return NumberPayments_Validate::validate_eindex($value);
  }


  // -------------------------
  // Availability
  // -------------------------
  public function is_available(): bool
  {
    return $this->get_option('enabled') === 'yes'
      && !empty($this->account_code)
      && !empty($this->token)
      && !empty($this->merchant_id)
      && !empty($this->api_url);
  }
}

// Register gateway
add_filter('woocommerce_payment_gateways', function ($methods) {
  $methods[] = 'WC_Gateway_NumberPayments';
  return $methods;
});
