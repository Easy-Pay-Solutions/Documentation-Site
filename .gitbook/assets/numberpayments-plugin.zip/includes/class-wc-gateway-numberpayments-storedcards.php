<?php
if (!defined('ABSPATH')) exit;

/**
 * Plugin Name: number.tech Payment Gateway
 * Description: methods for storing cards
 */

class numberpayments_storedcards {

  protected $NumberAPI;

  public function __construct( $api ) {
    $this->NumberAPI = $api;
  }

  public function delete_saved_payment( $token_id, $token ) { 

    // This is the remote reference (e.g., Number's consent id)
    $remote_token = $token->get_token();

		 error_log('In delete saved payment token ' . $remote_token);

		$success = $this->NumberAPI->delete_consent($remote_token);  
		 if (!$success) {
        error_log('Failed to delete remote token ' . $remote_token);
    }
  }


	


}