<?php
if (!defined('ABSPATH')) exit;

class NumberPayments_Validate
{

  public static function validate_api_url($value)
  {

    $value = esc_url_raw(trim($value));

    if (!filter_var($value, FILTER_VALIDATE_URL)) {
      WC_Admin_Settings::add_error('Invalid API URL');
      return '';
    }

    return $value;
  }

  public static function validate_merchant_id($value)
  {

    $value = trim($value);
    if (!ctype_digit($value)) {
      WC_Admin_Settings::add_error('Merchant ID must be a whole number.');
      return '';
    }

    return (string) absint($value);
  }

  public static function validate_eindex($value)
  {
    $value = trim($value);
    if (!ctype_digit($value)) {
      WC_Admin_Settings::add_error('EIndex must be numeric and greater than 299');
      return '0';
    }
    if ($value < 300) {
      WC_Admin_Settings::add_error('EIndex must be numeric and greater than 299');
      return '0';
    }

    return (string) absint($value);
  }

  public static function check_required($value, $field_name)
  {
    $value = trim((string) $value);

    if (empty($value)) {
      static $shown = [];

      $message = $field_name . ' is required';

      if (!isset($shown[$message])) {
        WC_Admin_Settings::add_error($message);
        $shown[$message] = true;
      }
      return '';
    }
    return $value;
  }
}
