<?php
if (!defined('ABSPATH')) exit;

class NumberPayments_Encryption
{

    private string $cipher = 'AES-256-CBC';

    private function getKey(): string
    {

        if (!defined('Number_ENCRYPTION_KEY') || !Number_ENCRYPTION_KEY) {
            throw new Exception('Missing Number_ENCRYPTION_KEY.');
        }

        $key = hex2bin(Number_ENCRYPTION_KEY);

        if ($key === false) {
            throw new RuntimeException('Failed to decode encryption key.');
        }

        // AES-256 requires 32 bytes
        if (strlen($key) !== 32) {
            throw new RuntimeException('Encryption key must be 32 bytes.');
        }

        return $key;
    }

    public function decrypt(string $input): string|false
    {

        // First 24 chars = Base64 IV (16 bytes)
        $ivBase64 = substr($input, 0, 24);

        // Remaining chars = Base64 ciphertext
        $cipherBase64 = substr($input, 24);

        $iv = base64_decode($ivBase64, true);
        $cipher = base64_decode($cipherBase64, true);

        if ($iv === false || $cipher === false) {
            error_log('in decryption, either iv is false or cipher is false');
            return false;
        }

        // AES block IV size = 16 bytes
        if (strlen($iv) !== 16) {
            return false;
        }

        return openssl_decrypt(
            $cipher,
            $this->cipher,
            $this->getKey(),
            OPENSSL_RAW_DATA,
            $iv
        );
    }
}
