<?php
if (!defined('ABSPATH')) exit;


class numberpayments_api {

  public $sesskey = null;

  protected NumberPayments_Config $config;

  public function __construct(NumberPayments_Config $config)
  {
    $this->config = $config;
  }

  // -------------------------
  // Get session key
	// now returns api key instead of the 24 hour session key
  // -------------------------

  public function get_sesskey($force_refresh = false) {

	  return $this->config->apikey;
  
    $transient_key = 'my_api_gateway_sesskey';

    if ($force_refresh) {
      delete_transient($transient_key);
    }

    // Use in-memory cache first (per request)
    if ($this->sesskey && !$force_refresh) {
      return $this->sesskey;
    }

    $sesskey = get_transient($transient_key);

    if ($sesskey !== false) {
      $this->sesskey = $sesskey;
      return $sesskey;
    }

    // Fetch new SessKey from API
    try {
      $sesskey = $this->authenticate();
    } catch (Exception $e) {
      $base_message = 'Authentication error: ' . sprintf('[%s] %s', get_class($e), $e->getMessage());
      error_log($base_message);
      wc_get_logger()->error($base_message, ['source' => 'number-payments']);

      return;
    }


    // Store for slightly less than 24h
    set_transient($transient_key, $sesskey, 23 * HOUR_IN_SECONDS);

    $this->sesskey = $sesskey;
    return $sesskey;
  }


  // -------------------------
  // Call number's authentication API to get their SessKey
  // -------------------------
  public function authenticate(): ?string {  

    if (empty($this->config->api_url) || empty($this->config->account_code) || empty($this->config->token)) {
      throw new InvalidArgumentException('missing API credentials for authentication');
    }

    $response = wp_remote_post(
      rtrim($this->config->api_url, '/') . '/Authenticate',
      [
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => json_encode([
          'AcctCode' => $this->config->account_code,
          'Token'    => $this->config->token
        ]),
      ]
    );

    if (is_wp_error($response)) {
      throw new RuntimeException('Authentication API request error: ' . $response->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code < 200 || $code >= 300) {
      throw new RuntimeException('Authentication API request http error: '  . $code);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!is_array($data)) {
      error_log('NumberPayments auth invalid JSON response');
      return null;
    }

    if ($data['AuthenticateResult']['FunctionOk'] !== true) {
      throw new RuntimeException('Number Payments API authentication error: ' . $data['AuthenticateResult']['ErrMsg']);
    }

    // Extract the SessKey from AuthenticateResult
    if (isset($data['AuthenticateResult']['SessKey']) && !empty($data['AuthenticateResult']['SessKey'])) {
      $session_key = $data['AuthenticateResult']['SessKey'];
      WC()->session->set('numberpayments_session_key', $session_key);
      return $session_key;
    } else {
      error_log('Number Payments API response missing SessKey');
      return '';
    }
  }

  // -------------------------
  // Generate PayForm URL - use after order is created (2 page checkout)
  // -------------------------
  public function generate_url(WC_Order $order): string
  {
    $amount = (float) $order->get_total();
    $sess_key = $this->get_sesskey();

    if (!$sess_key) {
      throw new InvalidArgumentException('SessionKey is required');
    }

    $payer = [
      'Firstname' => (string) $order->get_billing_first_name(),
      'Lastname'  => (string) $order->get_billing_last_name(),
      'BillingAddress' => [
        'StreetAddress' => (string) $order->get_billing_address_1(),
        'City'          => (string) $order->get_billing_city(),
        'State'         => (string) $order->get_billing_state(),
        'ZIP'           => (string) $order->get_billing_postcode(),
        'Country'       => (string) $order->get_billing_country(),
      ],
      'Email' => (string) $order->get_billing_email(),
      'Phone' => (string) $order->get_billing_phone(),
    ];

    $body = [
      'InitParams' => [
        'MerchID' => (int) $this->config->merchant_id,
        'PostURL' => '',
        'RedirectURL' => '',
        'WTYPE' => $this->config->apple_domain ? $this->config->apple_domain : 'PF',
        'REF_ID' => $order->get_id(),
        'RPGUID' => '',
        'EndPoint' => 'payform/PF.aspx',
        'EINDEX' => $this->config->eIndex,
        'Amounts' => [
          'Amount' => $amount,
          'Surcharge' => 0,
          'TotalAmt' => $amount,
        ],
        'Payer' => $payer,
        'WidOptions' => [
          'eVisible'    => $this->config->eVisible,
          'eReadOnly'   => $this->config->eReadOnly,
          'eStyles'     => $this->config->eStyles,
          'eSubmission' => $this->setSubmissionOptions($this->config),
          'eFeatures'   => ($this->config->useWallets) ? '0024' : '0020',
          'eColors'     => $this->config->eColors,
        ],
      ]
    ];

    $response = wp_remote_post(
      rtrim($this->config->api_url, '/') . '/CardSale/InitForm',
      [
        'headers' => [
          'Content-Type' => 'application/json',
          'SessKey'      => $sess_key,
        ],
        'body'    => json_encode($body),
        'timeout' => 360,
      ]
    );

    if (is_wp_error($response)) {
      throw new RuntimeException($response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if ($data['PaymentInitResult']['FunctionOk'] !== true) {
      throw new RuntimeException('Error generating payment URL: ' . $data['PaymentInitResult']['ErrMsg']);
    }

    $iframe_url = $data['PaymentInitResult']['PaymentUrl'] ?? '';

    if (!$iframe_url) {
      error_log('Failed to generate payment form for order ' . $order_id);
      return '';
    }

    return $iframe_url;
  }

	 // -------------------------
  // Generate PayForm URL prior to order processing
  // -------------------------
  public function generate_iframe_url($amount): string {  
   
    $sess_key = $this->get_sesskey();

    if (!$sess_key) {
      throw new InvalidArgumentException('SessionKey is required');
    }

    $payer = [
      'Firstname' => '',
      'Lastname'  => '',
      'BillingAddress' => [
        'StreetAddress' => '',
        'City'          => '',
        'State'         => '',
        'ZIP'           => '',
        'Country'       => '',
      ],
      'Email' => '',
      'Phone' => '',
    ];

    $body = [
      'InitParams' => [
        'MerchID' => (int) $this->config->merchant_id,
        'PostURL' => '',
        'RedirectURL' => '',
        'WTYPE' => $this->config->apple_domain ? $this->config->apple_domain : 'PF',
        'REF_ID' => '',
        'RPGUID' => '',
        'EndPoint' => 'payform/PF.aspx',
        'EINDEX' => $this->config->eIndex,
        'Amounts' => [
          'Amount' => $amount,
          'Surcharge' => 0,
          'TotalAmt' => $amount,
        ],
        'Payer' => $payer,
        'WidOptions' => [
          'eVisible'    => $this->config->eVisible,
          'eReadOnly'   => $this->config->eReadOnly,
          'eStyles'     => $this->config->eStyles,
          'eSubmission' => $this->setSubmissionOptions($this->config),
          'eFeatures'   => ($this->config->useWallets) ? '0024' : '0020',
          'eColors'     => $this->config->eColors,
        ],
      ]
    ]; 

    $response = wp_remote_post(
      rtrim($this->config->api_url, '/') . '/CardSale/InitForm',
      [
        'headers' => [
          'Content-Type' => 'application/json',
          'SessKey'     => $sess_key,
        ],
        'body'    => json_encode($body),
        'timeout' => 360,
      ]
    );

    if (is_wp_error($response)) {
      throw new RuntimeException($response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if ($data['PaymentInitResult']['FunctionOk'] !== true) {
      throw new RuntimeException('Error generating payment URL: ' . $data['PaymentInitResult']['ErrMsg']);
    }

    $iframe_url = $data['PaymentInitResult']['PaymentUrl'] ?? '';

    if (!$iframe_url) {
      error_log('Failed to generate payment form iframe URL');
      return '';
    }		
		return $iframe_url;		
  }

  // -------------------------
  // create the iframe URL for consent only
  // -------------------------
  public function generate_consent_url(WC_Customer $customer): string {  

    $sess_key = $this->get_sesskey();
    if (!$sess_key) {
      throw new InvalidArgumentException('SessionKey is required');
    }

    $body = [
      'InitParams' => [
        'MerchID' => (int) $this->config->merchant_id,
        'PostURL' => '',
        'RedirectURL' => '',
        'WTYPE' => $this->config->apple_domain ?: 'PF',
        'REF_ID' => '',
        'RPGUID' => '',
        'EndPoint' => 'payform/PF.aspx',
        'EINDEX' =>  '',

        // ?? IMPORTANT: no amounts for tokenization
        'Amounts' => [
          'Amount' => 0,
          'Surcharge' => 0,
          'TotalAmt' => 0,
        ],

        'Payer' => [
          'Firstname' => $customer->get_first_name(),
          'Lastname'  => $customer->get_last_name(),
          'BillingAddress' => [
            'StreetAddress' => $customer->get_billing_address_1(),
            'City'          => '',
            'State'         => '',
            'ZIP'           => $customer->get_billing_postcode(),
            'Country'       => '',
          ],
          'Email'     => wp_get_current_user()->user_email,
          'Phone' => '',
        ],

        'WidOptions' => ['eVisible' => $this->config->savedcard_eVisible, 'eReadOnly' => $this->config->savedcard_eReadOnly, 'eStyles' => $this->config->savedcard_eStyles, 'eSubmission' => '1420', 'eFeatures' => ($this->config->useWallets) ? '0024' : '0020', 'eColors' => $this->config->savedcard_eColors],
      ]
    ];

    $response = wp_remote_post(
      rtrim($this->config->api_url, '/') . '/CardSale/InitForm',
      [
        'headers' => [
          'Content-Type' => 'application/json',
          'SessKey'      => $sess_key,
        ],
        'body'    => json_encode($body),
        'timeout' => 360,
      ]
    );

    if (is_wp_error($response)) {
      throw new RuntimeException($response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['PaymentInitResult'])) {
      throw new RuntimeException("Invalid API response for PaymentInitResult");
    }
    if ($data['PaymentInitResult']['FunctionOk'] !== true) {
      throw new RuntimeException('Error generating payment URL: ' . $data['PaymentInitResult']['ErrMsg']);
    }

    $iframe_url = $data['PaymentInitResult']['PaymentUrl'] ?? '';

    return $iframe_url;		
  }

  /**
   * Validate a TXID via Number.tech API     
   * @param string $txid Transaction ID to validate
   * @param WC_Order $order WooCommerce order object
   * @return bool True if valid, false otherwise
   */
  public function validate_transaction(string $txid, WC_Order $order): bool {  

   // error_log('In validate transaction');

    if (!$txid || !$order) {
      return false;
    }

    $api_url = rtrim($this->config->api_url, '/') . '/Query/Transaction';
    $sess_key = $this->get_sesskey();

    $query = "(A={$this->config->merchant_id})&&(H={$txid})";
    $data = ["Query" => $query];

    $response = wp_remote_post($api_url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'SessKey'      => $sess_key,
      ],
      'body'    => wp_json_encode($data),
      'timeout' => 200,
    ]);

    if (is_wp_error($response)) {
      throw new RuntimeException("Query Transaction API error: " . $response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['Transaction_QueryResult'])) {
      throw new RuntimeException("Query Transaction API invalid response ");
    }

    if ($data['Transaction_QueryResult']['FunctionOk'] !== true) {
      throw new RuntimeException('Error querying transactions: ' . $data['Transaction_QueryResult']['ErrMsg'] . $txid);
    }

    $transactions = $data['Transaction_QueryResult']['Transactions'] ?? [];
    if (empty($transactions) || !is_array($transactions)) {
      error_log('No transactions found for TXID ' . $txid);
      return false;
    }


    // 1 Check TXID matches  
    $match = null;

    foreach ($transactions as $tx) {
      if (!empty($tx['ID']) && (string)$tx['ID'] === (string)$txid) {
        $match = $tx;
        break;
      }
    }
    if (!$match) {
      error_log('TXID mismatch: expected ' . $txid . ', not found in response');
      return false;
    }

    // 2 Check amount matches order total
    $expected = round((float)$order->get_total(), 2);
    $actual   = round((float)($match['AMOUNT'] ?? 0), 2);

    if ($expected !== $actual) {
      error_log("Order {$txid}: Amount mismatch: expected {$expected}, got {$actual}");
      return false;
    }

    // 3 check if order is recent (last 10 mins)
    $recent = $this->isWithinLastTenMinutes($tx['CreatedOn']);
    if (!$recent) {
      error_log('TXID ' . $txid . ' is not validated due to timestamp mismatch');
      return false;
    }

    return true;
  }

  // -------------------------
  // Validate stored card and retrieve details
  // Uses number Consent FullDetail
  // -------------------------
  public function validate_consent(string $txid): NumberPayments_Card {     

    if (!$txid) {
      throw new InvalidArgumentException('TXID is required');
    }

    $api_url = rtrim($this->config->api_url, '/') . '/Query/ConsentAnnual_FullDetail';
    $sess_key = $this->get_sesskey();
    $query = ["ConsentID" => $txid];

    $response = wp_remote_post($api_url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'SessKey'      => $sess_key,
      ],
      'body'    => wp_json_encode($query),
      'timeout' => 200,
    ]);

    if (is_wp_error($response)) {
      throw new RuntimeException('Number API Consent FullDetail Error: ' . $response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (empty($data['ConsentAnnual_FullDetailResult'])) {
      throw new RuntimeException("Invalid API response for TXID {$txid}");
    }

    try {
      $card = $this->getConsentData($data);
    } catch (Throwable $e) {
      throw new InvalidArgumentException('Cannot validate stored card ID ' . $txid . ': ' . $e->getMessage(), 0, $e);
    }
    return $card;
  }

  // -------------------------
  // VOID the Payment
  // -------------------------
  public function void_payment(string $txid): void {  

    if ($txid === '') {
      throw new InvalidArgumentException('TxID cannot be empty');
    }

    $api_url = rtrim($this->config->api_url, '/') . '/CardSale/Void';
    $sess_key = $this->get_sesskey();

    $data = ["TxID" => $txid];

    $response = wp_remote_post($api_url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'SessKey'      => $sess_key,
      ],
      'body'    => wp_json_encode($data),
      'timeout' => 200,
    ]);

    if (is_wp_error($response)) {
      throw new RuntimeException('Void Payment API error: ' . $response->get_error_message());
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!is_array($data)) {
      throw new RuntimeException('Invalid JSON response from void payment API');
    }

    if (empty($data['Transaction_VoidResult'])) {
      throw new RuntimeException('Missing void result for TxID ' . $txid);
    }

    $result = $data['Transaction_VoidResult'];

    if (!array_key_exists('TxApproved', $result)) {
      throw new RuntimeException('Missing TxApproved flag for TxID ' . $txid);
    }

    if ($result['FunctionOk'] !== true) {
      throw new RuntimeException('Remote API reported failure when voiding ' . $txid . ': ' . $result['ErrMsg']);
    }

    if ($result['TxApproved'] !== true) {
      throw new RuntimeException('Void not approved for TxID ' . $txid);
    }
  }


  // -------------------------
  // Delete a stored card at number
  // -------------------------
  public function delete_consent(string $cid): void {  

    if ($cid === '') {
      throw new InvalidArgumentException('ConsentID cannot be empty');
    }

    $api_url = rtrim($this->config->api_url, '/') . '/ConsentAnnual/Cancel';
    $sess_key = $this->get_sesskey();

    $response = wp_remote_post($api_url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'SessKey'      => $sess_key,
      ],
      'body'    => wp_json_encode(['ConsentID' => $cid]),
      'timeout' => 200,
    ]);

    if (is_wp_error($response)) {
      throw new RuntimeException(
        'Cancel Consent API error: ' . $response->get_error_message()
      );
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!is_array($data)) {
      throw new RuntimeException('Invalid JSON response from cancel API');
    }

    if (empty($data['ConsentAnnual_CancelResult'])) {
      throw new RuntimeException('Missing cancel result for ConsentID ' . $cid);
    }

    $result = $data['ConsentAnnual_CancelResult'];

    if (!array_key_exists('FunctionOk', $result)) {
      throw new RuntimeException('Missing FunctionOk flag for ConsentID ' . $cid);
    }

    if ($result['FunctionOk'] !== true) {
      throw new RuntimeException('Remote API reported failure cancelling consentID ' . $cid . ': ' . $result['ErrMsg']);
    }
  }

  // -------------------------
  // Charge a stored card at number
  // -------------------------
  public function charge_consent(string $cid, float $amount): int
  {

    if ($cid === '') {
      throw new InvalidArgumentException('ConsentID cannot be empty');
    }
    if ($amount <= 0) {
      throw new InvalidArgumentException('Amount must be greater than zero');
    }

    $api_url = rtrim($this->config->api_url, '/') . '/ConsentAnnual/ProcPayment';
    $sess_key = $this->get_sesskey();

    $response = wp_remote_post($api_url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'SessKey'      => $sess_key,
      ],
      'body'    => wp_json_encode(['ConsentID' => (int) $cid, 'ProcessAmount' => (float) $amount]),
      'timeout' => 600,
    ]);

    if (is_wp_error($response)) {
      throw new RuntimeException(
        'Charge Consent API error: ' . $response->get_error_message()
      );
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!is_array($data)) {
      throw new RuntimeException('Invalid JSON response from charge consent API');
    }

    if (empty($data['ConsentAnnual_ProcPaymentResult'])) {
      throw new RuntimeException('Missing ProcPaymentResult for ConsentID ' . $cid);
    }

    $result = $data['ConsentAnnual_ProcPaymentResult'];

    if (!array_key_exists('FunctionOk', $result)) {
      throw new RuntimeException('Missing FunctionOk flag for ConsentID ' . $cid);
    }

    if ($result['FunctionOk'] !== true) {
      throw new RuntimeException('Remote API reported failure charging consent: ' . $result['ErrMsg'] . 'CID' . $cid);
    }

    if ($result['TxApproved'] == true) {
      return $result['TxID'];
    } else {
      return 0;
    }
  }

  // -------------------------
  // Refund a transaction
  // -------------------------
  public function apply_credit(string $txid, float $amount): bool
  {

    if ($txid === '') {
      throw new InvalidArgumentException('Transaction ID cannot be empty');
    }
    if ($amount <= 0) {
      throw new InvalidArgumentException('Amount must be greater than zero');
    }

    $api_url = rtrim($this->config->api_url, '/') . '/CardSale/ApplyCredit';
    $sess_key = $this->get_sesskey();

    $response = wp_remote_post($api_url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'SessKey'      => $sess_key,
      ],
      'body'    => wp_json_encode(['TxID' => (int) $txid, 'CreditAmount' => (float) $amount]),
      'timeout' => 600,
    ]);

    if (is_wp_error($response)) {
      throw new RuntimeException(
        'Credit Transaction API error: ' . $response->get_error_message()
      );
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!is_array($data)) {
      throw new RuntimeException('Invalid JSON response from credit transaction API');
    }

    if (empty($data['Transaction_ApplyCreditResult'])) {
      throw new RuntimeException('Missing ApplyCreditResult for TxID ' . $txid);
    }

    $result = $data['Transaction_ApplyCreditResult'];

    if (!array_key_exists('FunctionOk', $result)) {
      throw new RuntimeException('Missing FunctionOk flag for TxID ' . $txid);
    }

    if ($result['FunctionOk'] !== true) {
      throw new RuntimeException('Remote API reported failure applying refund: ' . $result['ErrMsg'] . $txid);
    }

    return $result['TxApproved'];
  }


  // -------------------------
  // Convert json ConsentFullDetail response to savedcard object
  // -------------------------		
  private function getConsentData(array $data): NumberPayments_Card
  {

    // Grab the relevant sections
    $accountHolder = $data['ConsentAnnual_FullDetailResult']['AccounttHolder'];
    $consent = $data['ConsentAnnual_FullDetailResult']['ConsentAnnual'];

    // if the API query shows this is an old stored card, do not keep it. Prevents spoofing
    if (! $this->isWithinLastTenMinutes($consent['CreatedOn'])) {
      throw new UnexpectedValueException('Stored Card Validation - timestamp is old');
    }
    if ($consent['IsEnabled'] == false) {
      throw new UnexpectedValueException('Stored Card Validation - record is disabled');
    }

    // Extract and transform values
    // Last 4 digits 
    $cardLast4 = $consent['AcctNo'];

    // Card type mapping (VI ? Visa, etc.)
    $cardTypeMap = [
      'VI' => 'Visa',
      'MC' => 'MasterCard',
      'AM' => 'Amex',
      'DI' => 'Discover'
    ];

    $cardType = $cardTypeMap[$accountHolder['CardType']] ?? $accountHolder['CardType'];

    // Expiration date (format: 1229 ? MMYY)
    $exp = $accountHolder['ExpDate'];
    $expMonth = substr($exp, 0, 2);
    $expYear = '20' . substr($exp, 2, 2);

    // Create your object
    $card = new NumberPayments_Card($consent['ID'], $cardLast4, $cardType, $expMonth, $expYear, 0);
    return ($card);
  }

  private function isWithinLastTenMinutes(string $jsonDate): bool
  {

    if (!preg_match('/\/Date\((\d+)([+-]\d{4})?\)\//', $jsonDate, $matches)) {
      return false; // invalid format
    }

    $milliseconds = (int)$matches[1];
    $timestamp = (int)($milliseconds / 1000); // convert to seconds

    $now = time();

    // Check if it's within the last 10 minutes (600 seconds)
    return ($now - $timestamp) <= 600 && ($now - $timestamp) >= 0;
  }

  private function setSubmissionOptions(NumberPayments_Config $settings): string
  {

    $binary = '100000';
    if ($settings->AVSFull == true)
      $binary = '1' . $binary;
    else
      $binary = '0' . $binary;
    if ($settings->AVSPartial == true)
      $binary = '1' . $binary;
    else
      $binary = '0' . $binary;
    if ($settings->CVV_match == true)
      $binary = '1' . $binary;
    else
      $binary = '0' . $binary;
    if ($settings->payment_type == 'payment')
      $binary = '01' . $binary;
    else
      $binary = '11' . $binary;

    $binary = '00000' . $binary;

    $options = strtoupper(str_pad(base_convert(trim($binary), 2, 16), 4, '0', STR_PAD_LEFT));
    return $options;
  }
}
