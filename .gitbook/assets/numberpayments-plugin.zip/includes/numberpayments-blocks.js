const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { getSetting } = window.wc.wcSettings;
const { createElement } = window.wp.element;

const settings = getSetting('numberpayments_data', {});
//const iframeUrl = settings.iframe_url;



// ?? Replace this with dynamic value later
// const iframeUrl = settings.iframe_url;
const iframeUrl = 'https://easypay5.com/EP_Intl/PA.aspx?eGUID=CF4348C0&CS=021&Digest=0RGN9dJnHGonbw51ZLUcbQ';

const Content = () => {
  return createElement(
    'div',
    { style: { width: '100%' } },
    createElement('iframe', {
      src: iframeUrl,
      style: {
        width: '100%',
        height: '600px',
        border: 'none'
      }
    })
  );
};

registerPaymentMethod({
  name: 'numberpayments',
  label: 'NumberPayments',
  content: createElement(Content),
  edit: createElement(Content),
  canMakePayment: () => true,
  ariaLabel: 'NumberPayments',
  supports: {
    features: ['products'],
  },
});