﻿

///  sends a reset to Verifone device
function ResetVerifone() {
    $.ajax({
        type: "GET",
        url: "https://localhost:8031/VerifoneSVC/service/GetCard?Option=10",

        success: function (data) {
            var Resp = data.split("|"); // parse response
            $('#StatusLabel').html(Resp[1]); // show results
            setTimeout("$('#StatusLabel').html('')", 3000) // clear results after 3 seconds

        },
        error: function (xhr, status, error) {
            alert("Verifone Connection Error " + error); // show error if exists

        }
    });
}

///  discontinues processing current transaction and additionally sends a reset
function UnlockVerifone() {
    $.ajax({
        type: "GET",
        url: "https://localhost:8031/VerifoneSVC/service/GetCard?Option=911",

        success: function (data) {
            var Resp = data.split("|"); // parse response
            $('#StatusLabel').html(Resp[1]); // show results
            setTimeout("$('#StatusLabel').html('')", 3000) // clear results after 3 seconds

        },
        error: function (xhr, status, error) {
            alert("Verifone Connection Error " + error); // show error if exists
        }
    });
}

//// Initiates an EMV sale with Option to Save Card  
function EMVSaleCombo(SaveCard) {

    var AcctHolderJson = GetAcctHolderJson();
    var EndCustJson = GetEndCustJson();
    var PurchdetailsJson = GetPurchDetailsJson();

    var amount = $('#Amount').val();
    amount = amount.replace('$', "");
    amount = amount.replace(',', "");

    $.ajax({
        type: "GET",
        url: "https://localhost:8031/VerifoneSVC/service/GetEmvComboJson?SessKey=" + $('#HdSesskey').val() + "&AcctHolderJson=" + AcctHolderJson + "&EndCustJson=" + EndCustJson + "&PurchDetailsJson=" + PurchdetailsJson + "&MerchID=" + $('#MerchID').val() + "&Amount=" + amount + "&SaveCard=" + SaveCard,
        success: function (data) {

            //a hex string is returned , this must be converted to a byte array and then to UTF text , the result is an XML object
            alert(stringFromUTF8Array(hexToBytes(data)));

        },
        error: function (xhr, status, error) {
            alert("Verifone Middleware Error " + error); // show error if exists

        }

    });

}



/// initiates Manual Transaction
function ManualSaleCombo(SaveCard) {

    var AcctHolderJson = GetAcctHolderJson();
    var EndCustJson = GetEndCustJson();
    var PurchdetailsJson = GetPurchDetailsJson();
    var amount = $('#Amount').val();
    amount = amount.replace('$', "");
    amount = amount.replace(',', "");

    $.ajax({
        type: "GET",
        url: "https://localhost:8031/VerifoneSVC/service/GetManualComboJson?SessKey=" + $('#HdSesskey').val() + "&AcctHolderJson=" + AcctHolderJson + "&EndCustJson=" + EndCustJson + "&PurchDetailsJson=" + PurchdetailsJson + "&MerchID=" + $('#MerchID').val() + "&Amount=" + amount + "&SaveCard=" + SaveCard,
        success: function (data) {
            //a hex string is returned , this must be converted to a byte array and then to UTF text , the result is an XML object
            alert(stringFromUTF8Array(hexToBytes(data)));

        },
        error: function (xhr, status, error) {

            alert("Verifone Middleware Error " + error); // show error if exists


        }

    });

}

function SaveCardChip() {


    var AcctHolderJson = GetAcctHolderJson();
    var EndCustJson = GetEndCustJson();
    var PurchdetailsJson = GetPurchDetailsJson();
    var AnnualDetailsJson = GetAnnualParamsJson();

    $.ajax({
        type: "GET",
        url: "https://localhost:8031/VerifoneSVC/service/GetAnnualJson?SessKey=" + $('#HdSesskey').val() + "&AcctHolderJson=" + AcctHolderJson + "&EndCustJson=" + EndCustJson + "&PurchDetailsJson=" + PurchdetailsJson + "&MerchID=" + $('#MerchID').val() + "&AnnualParams=" + AnnualDetailsJson + "&IsManual=False",
        success: function (data) {

            //a hex string is returned , this must be converted to a byte array and then to UTF text , the result is an XML object
            alert(stringFromUTF8Array(hexToBytes(data)));

        },
        error: function (xhr, status, error) {

            alert("Verifone Middleware Error " + error); // show error if exists


        }

    });

}



// object helpers
function address(Address1, Address2, City, State, ZIP, Country) {

    this.Address1 = Address1;
    this.Address2 = Address2;
    this.City = City;
    this.State = State;
    this.ZIP = ZIP;
    this.Country = Country;

}
// object helpers
function person(Firstname, Lastname, maddress, Email, Phone) {

    this.Firstname = Firstname;
    this.Lastname = Lastname;
    this.address = maddress;
    this.Email = Email;
    this.Phone = Phone;

}
// object helpers
function PurchDetails(REFID, RPGUID, ServiceDesc) {
    this.REFID = REFID;
    this.RPGUID = RPGUID;
    this.ServiceDesc = ServiceDesc;
}

/// creates an Accountholder Oject and converts to Json
function GetAcctHolderJson() {

    var mAddress = new address($('#Address1').val(), '', $('#City1').val(), $('#State1').val(), $('#Zip1').val(), "USA");
    var mAcctHolder = new person($('#FirstName1').val(), $('#LastName1').val(), mAddress, $('#Email1').val(), '207-453-4587');
    return JSON.stringify(mAcctHolder);

}
/// creates End Customer Oject and converts to Json
function GetEndCustJson() {
    var mAddress = new address($('#Address2').val(), '', $('#City2').val(), $('#State2').val(), $('#Zip2').val(), "USA");
    var mEndCustomer = new person($('#FirstName2').val(), $('#LastName2').val(), mAddress, '', '');
    return JSON.stringify(mEndCustomer);

}
/// creates Detail Oject and converts to Json
function GetPurchDetailsJson() {
    var REFID = $('#RefID').val();
    if (REFID.indexOf('#') >= 0) {
        REFID = REFID.replace('#', '?');
    }
    var RPGUID;
    var element = $('#RPGUID').val()
    if (element != null) {
        RPGUID = $('#RPGUID').val()
        if (RPGUID.indexOf('#') >= 0) {
            RPGUID = RPGUID.replace('#', '?');
        }
    }
    else {
        RPGUID = "";
    }
    var mPurchDetails = new PurchDetails(REFID, RPGUID, 'SERVICE DESCRIPTION HERE');
    return JSON.stringify(mPurchDetails);

}
function GetAnnualParamsJson() {

    var today = new Date().toISOString().slice(0, 10)
    var mAnnualDetails = new AnnualParams(today, 365, '10000', '1000000');
    return JSON.stringify(mAnnualDetails);


}
function AnnualParams(StartDate, NumDays, LimitPerCharge, LimitLifeTime) {

    this.StartDate = StartDate;
    this.NumDays = NumDays;
    if (LimitPerCharge.indexOf('$') >= 0) {
        LimitPerCharge = LimitPerCharge.replace('$', "");
    }
    if (LimitPerCharge.indexOf(',') >= 0) {
        LimitPerCharge = LimitPerCharge.replace(',', "");
    }
    this.LimitPerCharge = LimitPerCharge;
    if (LimitLifeTime.indexOf('$') >= 0) {
        LimitLifeTime = LimitLifeTime.replace('$', "");
    }
    if (LimitLifeTime.indexOf(',') >= 0) {
        LimitLifeTime = LimitLifeTime.replace(',', "");
    }
    this.LimitLifeTime = LimitLifeTime;

}



////////////////// data conversion helpers ////////////////////////////////////////////
/// covert byte array to UTF string
function stringFromUTF8Array(data) {
    const extraByteMap = [1, 1, 1, 1, 2, 2, 3, 0];
    var count = data.length;
    var str = "";

    for (var index = 0; index < count;) {
        var ch = data[index++];
        if (ch & 0x80) {
            var extra = extraByteMap[(ch >> 3) & 0x07];
            if (!(ch & 0x40) || !extra || ((index + extra) > count))
                return null;

            ch = ch & (0x3F >> extra);
            for (; extra > 0; extra -= 1) {
                var chx = data[index++];
                if ((chx & 0xC0) != 0x80)
                    return null;

                ch = (ch << 6) | (chx & 0x3F);
            }
        }

        str += String.fromCharCode(ch);
    }

    return str;
}
// Convert a hex string to a byte array
function hexToBytes(hex) {
    for (var bytes = [], c = 0; c < hex.length; c += 2)
        bytes.push(parseInt(hex.substr(c, 2), 16));
    return bytes;
}