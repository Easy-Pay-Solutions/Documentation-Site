(function ($) {

    let iframePaymentStarted = false;
    let gatewayHandled = false;
    let checkoutResult = null;

  //--------------------------
  // Show or hide the iframe based on whether a saved card is selected
  //--------------------------
  function toggleGatewayIframe() {

    const tokens = $('input[type="radio"][name*="payment-token"]');
    const newToken = tokens.filter('[value="new"]');
    const savedTokens = tokens.not('[value="new"]');

    if (!tokens.length) {
      $('.my-gateway-iframe-wrapper').show();
      return;
    }

    // No saved cards: automatically choose "Use a new payment method"
    if (!savedTokens.length && newToken.length) {
      newToken.prop('checked', true);
    }

    // Show iframe only when "Use a new payment method" is selected
    $('.my-gateway-iframe-wrapper').toggle(newToken.is(':checked'));
  }


toggleGatewayIframe();


$(document.body).on(  'change', 'input[type="radio"][name*="payment-token"]',  toggleGatewayIframe);

$(document.body).on( 'updated_checkout',  toggleGatewayIframe);

  //--------------------------
  // Reset checkout state after a gateway error
  //
function resetCheckoutAfterGatewayError(message) {

    gatewayHandled = false;
    iframePaymentStarted = false;


    // Remove WooCommerce processing state
    $('form.checkout').removeClass('processing').unblock();

    // Remove our processing overlay if present
    $('.my-gateway-processing').remove();


    showPaymentError( message || 'Payment could not be completed. Please try again.');

    // Scroll customer back to checkout payment area
    $('html, body').animate({
        scrollTop: $('.woocommerce-checkout-payment').offset().top - 50 }, 500);

    }


  //--------------------------
  // Show a payment error message to the customer
  //--------------------------
 function showPaymentError(message) {

   gatewayHandled = false;

   const $form = $('form.checkout');

   $form.removeClass('processing').unblock();

   $('.woocommerce-NoticeGroup-checkout, .woocommerce-error').remove();

   $form.prepend(
     '<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' +
     '<ul class="woocommerce-error" role="alert">' +
     '<li>' + message + '</li>' +
     '</ul>' +
     '</div>'
   );

   $('html, body').animate({
     scrollTop: $form.offset().top - 100
   }, 500);

   $(document.body).trigger('checkout_error');
        
    }

  //--------------------------
  // Show a processing overlay to the customer
  //--------------------------
    function showProcessing(message) {

        document.body.insertAdjacentHTML(
            'beforeend',
            `
            <div class="my-gateway-processing">
                <div class="spinner"></div>
                <p>${message}</p>
            </div>
            `
        );

    }


  // Prevent submit without token
  // This is for the "Add Payment Method" page, where the iframe returns a CID directly
  $('form#add_payment_method').on('submit', function (e) {
    if (!$('#my_gateway_card_token').val()) {
      e.preventDefault();
      showNotice('Please complete card entry first.');
    }
  });


  // --------------------------
  // Request a payment void from the gateway
  // --------------------------
function processVoid() {

    console.log('Requesting payment void');

    $.post(
        myGateway.ajax_url,
        {
            action: 'process_numberpayments_void',
            security: myGateway.nonce
        }
    )
    .done(function(res) {
      console.log('Void response', res);
      if (!res.success) {
        resetCheckoutAfterGatewayError( res.data?.message || 'An error occurred while attempting to void the payment.');
        return;
      }

      // Success
      resetCheckoutAfterGatewayError( res.data?.message || 'Your payment has been voided.');
    })
    .fail(function(xhr) {
      console.error('Void request failed', xhr);     
      resetCheckoutAfterGatewayError('An error occured after the order was processed and the payment void request failed.');
    });

}


  // --------------------------
  // Parse the decrypted string returned from the gateway
  // --------------------------
  function parseDecryptedString(str) {

    if (!str || typeof str !== 'string') {
      return null;
    }

    const parts = str.split('|');
    const result = {};

    for (
      let i = 0;
      i < parts.length;
      i += 2
    ) {

      const key = parts[i];
      const value = parts[i + 1];


      if (key) {
        result[key] = value ?? '';
      }

    }

    return result;
  }


  // --------------------------
  // Log javascript gateway error to the server for debugging
  // --------------------------
    function logGatewayError(message, data = {}) {
      try {
        $.post(myGateway.ajax_url, {
          action: 'numberpayments_js_error',
          nonce: myGateway.nonce,
          message: message,
          data: JSON.stringify(data)
        });
      }
      catch (err) {        
        console.error('Failed to log gateway error', err);
      }
    }


  //--------------------------
  // Get the order total from the WooCommerce checkout page
  //--------------------------
  function getGatewayTotal() {

    const value = $('#number-gateway-total').data('order-total');

    if (value === undefined || value === null) {
      throw new Error('Missing gateway order total');
    }

    return parseFloat(String(value).replace(/[^0-9.-]+/g, '')) || 0;
  }

    
  //--------------------------
  // Submit the payment to the PayForm iframe
  //--------------------------
    function submitIframePayment(result) {       

        if (iframePaymentStarted) {           
            return;
        }     

      try {

        if (!result || !result.order_id) {
          throw new Error('Missing order_id in submitIframePayment()');
        }

        const iframe = document.querySelector('.my-gateway-iframe');

        if (!iframe) {
          iframePaymentStarted = false;
          throw new Error('NumberPayments iframe not found');
        }

        if (!iframe.contentWindow) {
          throw new Error('Iframe contentWindow is unavailable');
        }
        
        const data = {

            firstname: $('#billing_first_name').val(),
            lastname: $('#billing_last_name').val(),
            address1: $('#billing_address_1').val(),
            zip: $('#billing_postcode').val(),
            refid: result.order_id,
            amount: getGatewayTotal(),
            action: 'submit'
        };

        iframePaymentStarted = true;
        iframe.contentWindow.postMessage(data, '*');

      }
      catch (err) {
        iframePaymentStarted = false;

        console.error('submitIframePayment failed', err);

        logGatewayError(err.message, {
          stack: err.stack,
          result: result,
          iframeFound: !!document.querySelector('.my-gateway-iframe'),
          paymentStarted: iframePaymentStarted,
          checkoutUrl: window.location.href,
          orderId: result?.order_id,
          userAgent: navigator.userAgent
        });

      } 
    }



    /*
     * Allow WooCommerce to create the order
     */
  $('form.checkout').on('checkout_place_order_numberpayments', function () {   
    return true;
  }
  );



    // ----------------------------------------
    // Intercept WooCommerce checkout success.     
    // We intentionally do NOT allow WooCommerce to redirect yet.
    // -----------------------------------------
  const originalAjax = $.ajax;

  $.ajax = function (options) {

    if ( options && options.url && options.url.indexOf('wc-ajax=checkout') !== -1) {

      const originalSuccess = options.success;

      options.success = function (result) {
        const selectedGateway = $('input[name="payment_method"]:checked').val();

        if (selectedGateway === 'numberpayments' && result.result === 'success') {
          checkoutResult = result;

          const selectedToken = $('input[name^="wc-numberpayments-payment-token"]:checked').val();

          if (selectedToken && selectedToken !== 'new') {               
            return originalSuccess.apply(this, arguments);
          }

// WooCommerce has finished creating the order.    
// Remove its "Leave site?" protection because our gateway controls the rest of the flow.
    
          window.onbeforeunload = null;
          $(window).off('beforeunload');
          $(window).off('beforeunload.checkout');

          submitIframePayment(result);

          // Save Woo response for later
          window.numberPaymentsWooResult = result;

          // Do not redirect yet
          return;
        }

        return originalSuccess.apply( this,  arguments);
      };

    }

    return originalAjax.apply(  this,  arguments);
  };



    // -------------------
    // Receive iframe response
    // -------------------
  window.addEventListener('message', async function (event) {

    try {

      if (event.origin !== 'https://easypay5.com') {
        return;
      }

      if (gatewayHandled) {
        return;
      }

      // PayForm validation/payment error   
      if (typeof event.data === 'string' && event.data.startsWith('ERROR=')) {
        const errorMessage = event.data.substring(6);
        resetCheckoutAfterGatewayError(errorMessage);
        return;
      }


      //Add payment method page.PayForm returns CID directly; This is NOT encrypted and does not require decrypt  
      if (typeof event.data === 'string' && event.data.startsWith('CID=')) {
        const cid = event.data.substring(4);
        console.log('Received consent id', cid);
        $('#my_gateway_card_token').val(cid);

        gatewayHandled = true;

        showProcessing('Saving your card...');
        document.querySelector('.my-gateway-iframe')?.remove();
        document.querySelector('form#add_payment_method')?.submit();

        return;
      }


      //Payment flows arrive encrypted. This includes: Payment only and Payment + Save Card combo
      gatewayHandled = true;

      let data;
      
        const response = await fetch(
          myGateway.restUrl,
          {
            method: 'POST',
            headers:
            {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(
              {
                ciphertext: event.data
              })
          }
        );

        const result = await response.json();

       // console.log('Decrypt response', result);

        if (!result.success || !result.data) {

          console.error('Unable to decrypt gateway response');

          processVoid();

          showPaymentError('Payment could not be completed. Your card has not been charged.');

          gatewayHandled = false;

          return;

        }

        data = parseDecryptedString(result.data);      

      // console.log('Parsed gateway data', data);

      if (!data) {
        gatewayHandled = false;
        return;
      }


      //COMBINED PAYMENT + SAVE CARD  
      if (data.TXID && data.CONSENTID) {

        // showProcessing('Completing order and saving card...');

        $.post(myGateway.ajax_url,
          {

            action: 'process_numberpayments_combo',
            security: myGateway.nonce,
            txid: data.TXID,
            cid: data.CONSENTID,
            expires: data.EXPDATE,
            card: data.CARDNO,
            cardtype: data.CARDTYPE,
            fee: data.FEE
          }

        )
          .done(function (res) {

           // console.log('Combo response', res);

            if (res.success) {
              window.location.href = res.data.redirect;
            }
            else {
              showPaymentError((res.data && res.data.message) || 'Payment verification failed');
            }

          })
          .fail(function (xhr) {

            logGatewayError('Combo AJAX failed', {
              status: xhr.status,
              response: xhr.responseText,
              txid: data.TXID
            });
          
            showPaymentError('Server error during payment verification');
          });

        return;
      }

      // payment only
      if (data.TXID) {

        //showProcessing('Completing order...');

        $.post(
          myGateway.ajax_url,
          {

            action: 'confirm_numberpayments_payment',
            security: myGateway.nonce,
            txid: data.TXID,
            card: data.CARDNO,
            cardtype: data.CARDTYPE,
            fee: data.FEE
          }
        )
          .done(function (res) {
           // console.log('Payment confirmation response', res);

            if (res.success) {
              window.location.href = res.data.redirect;
            }
            else {
              showPaymentError((res.data && res.data.message) || 'Payment verification failed');
            }

          })
          .fail(function (xhr) {
           
            logGatewayError('Payment confirmation failed', {
              status: xhr.status,
              response: xhr.responseText,
              txid: data.TXID
            });

            processVoid();

            showPaymentError('Server error during payment verification');
          });

        return;

      }

      console.error('Unknown PayForm response', data);
      logGatewayError('Unknown gateway response', {
        parsedData: data,
        rawData: event.data
      });

      gatewayHandled = false;
    }
    catch (err) {

      console.error('Gateway message handler failed', err);

      logGatewayError(err.message, {
        stack: err.stack,
        origin: event.origin,
        data: event.data,
        gatewayHandled: gatewayHandled,
        url: window.location.href
      });

      gatewayHandled = false;

      showPaymentError('An unexpected error occurred while processing your payment.');
    }

});


})(jQuery);