<?php
if (!defined('ABSPATH')) exit;

class NumberPayments_Config {
    public function __construct(
        public string $account_code,
        public string $token,
        public string $merchant_id,
        public string $api_url,
	public string $eIndex,
	public string $payment_type,
        public string $eVisible,
        public string $eReadOnly,
        public string $eStyles,
        public string $eColors,		
	public bool $useWallets,	
	public string $apple_domain,	
	public bool $AVSFull,
	public bool $AVSPartial,
	public bool $CVV_match					
    ) {}
}