<?php
if (!defined('ABSPATH')) exit;

class NumberPayments_Config {
    public function __construct(       
				public string $apikey,
        public string $merchant_id,
        public string $api_url,
				public string $eIndex,
				public string $payment_type,
        public string $eVisible,
        public string $eReadOnly,
        public string $eStyles,
        public string $eColors,		
				public string $savedcard_eVisible,
        public string $savedcard_eReadOnly,
        public string $savedcard_eStyles,
        public string $savedcard_eColors,
				public bool $useWallets,	
				public string $apple_domain,	
				public bool $AVSFull,
				public bool $AVSPartial,
				public bool $CVV_match	
				
    ) {}
}