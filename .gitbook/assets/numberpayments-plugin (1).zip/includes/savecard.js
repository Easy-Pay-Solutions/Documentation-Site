jQuery(function ($) {

  let gatewayHandled = false;

  function parseDecryptedString(str) {

    if (!str || typeof str !== 'string') {
      return null;
    }

    const parts = str.split('|');

    const result = {};

    for (let i = 0; i < parts.length; i += 2) {

      const key = parts[i];
      const value = parts[i + 1];

      if (key) {
        result[key] = value ?? '';
      }
    }

    return result;
  }

  async function parseGatewayMessage(message) {

    if (typeof message !== 'string') {
      return null;
    }    

    // remove iframe once we get a valid response   
    const frm = document.querySelector('.my-gateway-iframe');
    if (frm) {
      frm.remove();
    }

    // consent only requests go through addl verification api call not just encrypt
    if (message.startsWith('CID=')) {
      const token = message.slice(4);

      return {
        CONSENTID: token
      };
    }

    // decrypt the message
    const response = await fetch(myGateway.restUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ciphertext: message        
      })
    });

    const result = await response.json();

    if (!result.success || !result.data) {

      // Trigger your fallback action
      $.post(myGateway.ajax_url, {
        action: 'process_numberpayments_void',
        security: myGateway.nonce        
      })
      .done(function (response) {
        showPaymentError(response.data?.message);
      });

    }

    return parseDecryptedString(result.data);
  }

  function showNotice(message, type = 'error') {
    const wrapper = document.querySelector('.woocommerce-MyAccount-content, form.checkout');

    if (!wrapper) return;

    const notice = document.createElement('div');
    notice.className = `woocommerce-${type}`;
    notice.innerHTML = `<ul><li>${message}</li></ul>`;

    wrapper.prepend(notice);

    // auto-remove after 5s
    setTimeout(() => notice.remove(), 5000);
  }

  function showPaymentError(message) {

    const processing = document.querySelector('.my-gateway-processing');
    if (processing) {
      processing.remove();
    }

    const existing = document.querySelector('.my-gateway-error');

    if (existing) {
      existing.remove();
    }

    document.body.insertAdjacentHTML('beforeend', `
            <div class="my-gateway-error">
                <p class="my-gateway-error-text">${message}</p>

                <a class="my-gateway-retry-button"
                   href="<?php echo esc_url(wc_get_checkout_url()); ?>">
                    Return to checkout
                </a>
            </div>
        `);

    gatewayHandled = false;
  }

  function showProcessing(message = 'Processing...') {

    const processing = document.querySelector('.my-gateway-processing');
    if (processing) {
      processing.remove();
    }

    //
    // Use PHP-provided custom HTML if available
    //
    if (typeof myGatewayProcessingHtml !== 'undefined') {

      document.body.insertAdjacentHTML(
        'beforeend',
        myGatewayProcessingHtml
      );

      return;
    }

    //
    // fallback default
    //
    const html = `
        <div class="my-gateway-processing">
            <div class="spinner"></div>
            <p>${message}</p>
        </div>
    `;

    document.body.insertAdjacentHTML(
      'beforeend',
      html
    );
  }

  // Prevent submit without token
  $('form#add_payment_method').on('submit', function (e) {
    if (!$('#my_gateway_card_token').val()) {
      e.preventDefault();
      showNotice('Please complete card entry first.');
    }
  });

  
  window.addEventListener('message', async function (event) {

    if (event.origin !== 'https://easypay5.com') {
      return;
    }

    if (gatewayHandled) {
      return;
    }

    const data = await parseGatewayMessage(event.data);

    if (!data) {
      return;
    }

    gatewayHandled = true;    

    //
    // COMBINED PAYMENT + SAVE CARD
    //
    if (data.TXID && data.CONSENTID) {

      showProcessing('Completing order and saving card...');

      $.post(myGateway.ajax_url, {

        action: 'process_numberpayments_combo',
        security: myGateway.nonce,       
        txid: data.TXID,
        cid: data.CONSENTID,
        expires: data.EXPDATE,
        card: data.CARDNO,
        cardtype: data.CARDTYPE,
        fee: data.FEE
      })
        .done(function (res) {

          if (res.success) {
            window.location.href = res.data.redirect;
          } else {
            showPaymentError(
              (res.data && res.data.message) || 'Payment verification failed'
            );
          }

        })
        .fail(function () {

          showPaymentError(
            'Server error during payment verification'
          );
        });

      return;
    }

    //
    // PAYMENT ONLY
    //
    if (data.TXID) {
      showProcessing('Completing order...');

      $.post(myGateway.ajax_url, {
        action: 'confirm_numberpayments_payment',
        security: myGateway.nonce,       
        txid: data.TXID,
        card: data.CARDNO,
        cardtype: data.CARDTYPE,
        fee: data.FEE
      })
        .done(function (res) {
          if (res.success) {
            window.location.href = res.data.redirect;
          } else {
            showPaymentError((res.data && res.data.message) || 'Payment verification failed');
          }

        })
        .fail(function () {
          showPaymentError(
            'Server error during payment verification'
          );
        });

      return;
    }

    //
    // SAVE CARD ONLY
    //
    if (data.CONSENTID) {
      $('#my_gateway_card_token').val(data.CONSENTID);

      showNotice('Card details received. Saving...', 'success');

      document.querySelector('.my-gateway-iframe')?.remove();

      showProcessing('Saving your card...');

      document.querySelector('form#add_payment_method')?.submit();

      return;    
    }

    gatewayHandled = false;

  });


});