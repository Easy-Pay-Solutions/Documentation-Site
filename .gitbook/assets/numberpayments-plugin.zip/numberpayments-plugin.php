<?php
/**
 * Plugin Name: number.tech Payment Gateway
 * Plugin URI: https://docs.number.tech
 * Description: WooCommerce payment gateway for number.tech's PayForm
 * Version: 1.0.0
 * Author: Number
 */

if (!defined("ABSPATH")) {
    exit();
}

add_action("plugins_loaded", "numberpayments_init", 11);

function numberpayments_init()
{
    if (!class_exists("WooCommerce")) {
        add_action("admin_notices", "numberpayments_missing_wc_notice");
        return;
    }

    if (!class_exists("WC_Payment_Gateway")) {
        return;
    }

    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments-card.php";
    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments.php";
    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments-storedcards.php";
    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments-api.php";
    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments-config.php";
    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments-encryption.php";
    require_once plugin_dir_path(__FILE__) . "includes/class-wc-gateway-numberpayments-validate.php";

    // Register classic gateway
    add_filter("woocommerce_payment_gateways", function ($methods) {
        $methods[] = "WC_Gateway_NumberPayments";
        return $methods;
    });
}

add_action( "wp_ajax_confirm_numberpayments_payment", "numberpayments_confirm_handler");
add_action( "wp_ajax_nopriv_confirm_numberpayments_payment", "numberpayments_confirm_handler",);

add_action("wp_ajax_process_numberpayments_combo", [ "WC_Gateway_NumberPayments", "process_combo"]);
add_action("wp_ajax_nopriv_process_numberpayments_combo", ["WC_Gateway_NumberPayments", "process_combo"]);

add_action("wp_ajax_process_numberpayments_void", [ "WC_Gateway_NumberPayments", "process_void"]);
add_action("wp_ajax_nopriv_process_numberpayments_void", ["WC_Gateway_NumberPayments", "process_void"]);

add_action("rest_api_init", function () {
    register_rest_route("number/v1", "/decrypt", [
        "methods" => ["GET", "POST"],
        "callback" => "number_decrypt_message",
        "permission_callback" => "__return_true",
    ]);
});

function numberpayments_missing_wc_notice()
{
    if (!current_user_can("activate_plugins")) {
        return;
    }

    echo '<div class="notice notice-error"><p>';
    echo esc_html__(
        "The Number payment gateway requires WooCommerce to be installed and active.",
        "text-domain",
    );
    echo "</p></div>";
}

function numberpayments_confirm_handler()
{
    check_ajax_referer("my_gateway_nonce", "security");

    $order_id = WC()->session
        ? WC()->session->get("order_awaiting_payment")
        : 0;
    $txid = sanitize_text_field($_POST["txid"] ?? "");
    $cardno = sanitize_text_field($_POST["card"] ?? "");
    $cardtype = sanitize_text_field($_POST["cardtype"] ?? "");
    $fee_amount =
        isset($_POST["fee"]) && is_numeric($_POST["fee"])
            ? (float) $_POST["fee"]
            : 0;
    $order = wc_get_order($order_id);

    if (!$order || !$txid) {
        wp_send_json_error(["message" => "Invalid data"]);
    }

    $details = trim($cardtype . " " . $cardno);
    $note = "Payment completed via PayForm. TXID: " . $txid;

    if (!empty($details)) {
        $note .= ". Card: " . $details;
    }

    // surcharge
    if ($fee_amount > 0) {
        $fee = new WC_Order_Item_Fee();

        $fee->set_name("Credit Card Surcharge");
        $fee->set_amount($fee_amount);
        $fee->set_total($fee_amount);
        $order->add_item($fee);
        $order->calculate_totals();
    }

    $order->add_order_note($note);
    $order->set_transaction_id($txid);
    $order->payment_complete($txid);
    $order->save();

    wp_send_json_success([
        "redirect" => $order->get_checkout_order_received_url(),
    ]);
}

function numberpayments_get_settings()
{
    return get_option("woocommerce_numberpayments_settings", []);
}

function number_decrypt_message(WP_REST_Request $request)
{
    $ciphertext = $request->get_param("ciphertext");

    if (!$ciphertext) {
        return new WP_REST_Response(
            ["success" => false, "message" => "Missing ciphertext or iv"],
            400,
        );
    }

    try {
        $encryption = new NumberPayments_Encryption();
        $decrypted = $encryption->decrypt($ciphertext);

				error_log($ciphertext);

        if ($decrypted === false) {

					// if wrong eindex was used, could still get txid from message. proceed to void payment at number
					if (str_contains($ciphertext, 'TXID=')) {
				    $parts = explode('=', $ciphertext);
            $transactionId = $parts[1];
            WC()->session->set( 'transactionToVoid', $transactionId );
						error_log('transactionToVoid ' . $transactionId);
          }		

					 error_log('Error. Could not decrypt message from card processor');
				   wc_get_logger()->error("Decryption Error, cannot confirm payment", ['source' => 'number-payments']);				  

            return new WP_REST_Response(
                ["success" => false, "message" => "Decryption failed"],
                400,
            );
        }

        return ["success" => true, "data" => $decrypted];
    } 
		catch (Exception $e) {
        error_log("decryption error: " . $e->getMessage());
				wc_get_logger()->error('Decryption Error, cannot confirm payment', ['source' => 'number-payments']);
				wc_add_notice( 'An error occurred while completing the order. Your credit card charge has been voided.', 'error' );
        return new WP_REST_Response(
            [
                "success" => false,
                "message" => $e->getMessage(),
            ],
            500,
        );
    }
}
