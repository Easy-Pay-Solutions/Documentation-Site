<?php
if (!defined('ABSPATH')) exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class NumberPayments_Blocks extends AbstractPaymentMethodType {

    protected $name = 'numberpayments';

    public function initialize() {
        $this->settings = get_option('woocommerce_numberpayments_settings', []);
    }

    public function is_active() {
        return !empty($this->settings['enabled']) && $this->settings['enabled'] === 'yes';
    }

    public function get_payment_method_script_handles() {
        wp_register_script(
            'numberpayments-blocks',
            plugin_dir_url(__FILE__) . 'numberpayments-blocks.js',
            [ 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ],
            '1.0',
            true
        );

        return [ 'numberpayments-blocks' ];
    }

    public function get_payment_method_data() {
        return [
            'title'       => $this->settings['title'] ?? 'Credit Card Payment',
            'description' => $this->settings['description'] ?? '',
        ];
    }
}