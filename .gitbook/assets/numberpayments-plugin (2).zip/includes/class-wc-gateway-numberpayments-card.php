<?php
if (!defined('ABSPATH')) exit;

class NumberPayments_Card {

    private string $consentId;
    private string $last4;
    private string $brand;
    private int $expiryMonth;
    private int $expiryYear;
    private int $transactionID;

    public function __construct(
        string $consentId,
        string $last4,
        string $brand,
        int $expiryMonth,
        int $expiryYear,
        int $transactionID
    ) {
        // Validate last 4 digits
        if (!preg_match('/^\d{4}$/', $last4)) {
            throw new InvalidArgumentException('Invalid last 4 digits');
        }

        // Validate month
        if ($expiryMonth < 1 || $expiryMonth > 12) {
            throw new InvalidArgumentException('Invalid expiry month');
        }

        // Validate year (basic sanity check)
        $currentYear = (int) date('Y');
        if ($expiryYear < $currentYear || $expiryYear > $currentYear + 20) {
            throw new InvalidArgumentException('Invalid expiry year');
        }

        $this->consentId   = $consentId;
        $this->last4       = $last4;
        $this->brand       = strtolower($brand);
        $this->expiryMonth = $expiryMonth;
        $this->expiryYear  = $expiryYear;
        $this->transactionID  = $transactionID;
    }

    public function getConsentId(): string
    {
        return $this->consentId;
    }

    public function getLast4(): string
    {
        return $this->last4;
    }

    public function getBrand(): string
    {
        return $this->brand;
    }

    public function getExpiryMonth(): int
    {
        return $this->expiryMonth;
    }

    public function getExpiryYear(): int
    {
        return $this->expiryYear;
    }

    public function getTransactionID(): int
    {
        return $this->transactionID;
    }

    public static function fromProviderResponse(string $response): self
    {
        $parts = explode('|', $response);

        $data = [];

        for ($i = 0; $i < count($parts); $i += 2) {
            $data[strtoupper($parts[$i])] = $parts[$i + 1] ?? '';
        }

        [$month, $year] = explode('/', $data['EXPDATE']);

        return new self(
            consentId: $data['CONSENTID'],
            last4: $data['CARDNO'],
            brand: $data['CARDTYPE'],
            expiryMonth: (int) $month,
            expiryYear: 2000 + (int) $year,
            transactionID: $data['TRANSACTIONID']
        );
    }
}
